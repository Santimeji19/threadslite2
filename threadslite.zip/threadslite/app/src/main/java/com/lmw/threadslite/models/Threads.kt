package com.lmw.threadslite.models

data class Publicaciones(

    val autor: String,
    val titulo: String,
    val contenido: String,
)